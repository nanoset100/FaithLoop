"""
믿음루프(FaithLoop) - 오늘의 기록 (신앙 체크인)
감사/기도/말씀/적용 기록 입력 (텍스트, 이미지, 음성)
Step 2: 규칙 기반 추출
Step 3: LLM 기반 구조화 (Extractor)
Step 4: 음성 STT
Step 5: 이미지 Vision
"""
import streamlit as st
import re
from typing import Dict, List, Optional
from datetime import datetime
import tempfile
import os

st.set_page_config(page_title="오늘의 기록 - 믿음루프", page_icon="✍️", layout="wide")

# 로그인 체크
if "user" not in st.session_state or st.session_state.get("user") is None:
    st.warning("🔐 로그인이 필요합니다. 메인 페이지에서 로그인하세요.")
    st.stop()

user_id = st.session_state["user"].id

# === 자동 인덱싱 토글 값 로드 ===
from lib.supabase_db import get_profile
_profile = get_profile()
_settings = (_profile or {}).get("settings") or {}
if "auto_index_on_save" not in st.session_state:
    st.session_state["auto_index_on_save"] = bool(_settings.get("auto_index_on_save", False))


# === 규칙 기반 Extraction (폴백용) ===
def extract_by_rules(content: str) -> Dict[str, List[str]]:
    """
    규칙 기반으로 텍스트에서 구조화된 정보 추출
    """
    lines = content.strip().split('\n')
    
    tasks = []
    obstacles = []
    projects = []
    insights = []
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
        
        # task: '-' 또는 '•'로 시작하는 줄
        if line.startswith('-') or line.startswith('•') or line.startswith('*'):
            task_text = line.lstrip('-•* ').strip()
            if task_text:
                tasks.append(task_text)
        
        # obstacle: '!' 시작 또는 부정적 키워드 포함
        obstacle_keywords = ['문제', '어려움', '힘들', '막혀', '안됨', '실패', '오류', '버그']
        if line.startswith('!') or any(kw in line for kw in obstacle_keywords):
            obstacle_text = line.lstrip('! ').strip()
            if obstacle_text and obstacle_text not in obstacles:
                obstacles.append(obstacle_text)
        
        # project: '#프로젝트명' 형태
        project_matches = re.findall(r'#(\w+)', line)
        for proj in project_matches:
            if proj not in projects:
                projects.append(proj)
        
        # insight: 인사이트 키워드 포함
        insight_keywords = ['💡', '인사이트', '배움', '깨달음', '발견', '아이디어']
        if any(kw in line for kw in insight_keywords):
            insight_text = line.strip()
            if insight_text and insight_text not in insights:
                insights.append(insight_text)
    
    return {
        "tasks": tasks,
        "obstacles": obstacles,
        "projects": projects,
        "insights": insights,
        "people": [],
        "emotions": []
    }


st.title("✍️ 오늘의 기록")
st.caption("매일 감사와 말씀을 기록하세요")

# === 세션 상태 초기화 ===
if "transcribed_text" not in st.session_state:
    st.session_state.transcribed_text = ""
if "image_analysis" not in st.session_state:
    st.session_state.image_analysis = ""
if "uploaded_artifacts" not in st.session_state:
    st.session_state.uploaded_artifacts = []  # [{type, storage_path, metadata}]

# === 사이드바: AI 설정 ===
with st.sidebar:
    st.subheader("🤖 AI 설정")
    use_ai_extraction = st.toggle(
        "LLM 기반 구조화 사용",
        value=True,
        help="OpenAI를 사용하여 더 정확하게 정보를 추출합니다"
    )
    
    if use_ai_extraction:
        use_ingestor = st.checkbox(
            "텍스트 정리 (Ingestor)",
            value=False,
            help="텍스트를 정리/정규화한 후 분석"
        )
        generate_reflection = st.checkbox(
            "AI 코멘트 생성",
            value=True,
            help="체크인에 대한 짧은 AI 코멘트"
        )
    else:
        use_ingestor = False
        generate_reflection = False
    
    st.divider()
    st.caption("💡 LLM 미사용 시 규칙 기반으로 추출")


st.divider()

# === 체크인 폼 ===
with st.form("checkin_form"):
    # 영적 컨디션 선택
    st.subheader("오늘의 영적 컨디션은 어떤가요?")
    mood = st.radio(
        "영적 컨디션 선택",
        options=["great", "good", "neutral", "bad", "terrible"],
        format_func=lambda x: {
            "great": "🙏 평안/감사",
            "good": "✨ 은혜로움",
            "neutral": "📖 보통",
            "bad": "🌧️ 분주/낙심",
            "terrible": "😢 힘든 하루"
        }[x],
        horizontal=True,
        label_visibility="collapsed"
    )
    
    # 영적 에너지 슬라이더
    st.subheader("✝️ 영적 에너지")
    energy = st.slider(
        "현재 영적 에너지 레벨",
        min_value=1,
        max_value=10,
        value=5,
        help="1: 영적 갈급함 ~ 10: 하나님과 가까움"
    )
    
    st.divider()
    
    # 텍스트 입력 (멀티모달 결과 합치기)
    st.subheader("📝 오늘의 신앙 기록")
    st.caption("💡 팁: 아래 4가지 질문에 자유롭게 답해보세요")
    
    # 멀티모달에서 추가된 내용 합치기
    initial_content = ""
    if hasattr(st.session_state, 'add_to_content') and st.session_state.add_to_content:
        initial_content = st.session_state.add_to_content + "\n\n"
        st.session_state.add_to_content = ""  # 리셋
    
    content = st.text_area(
        "내용",
        value=initial_content,
        placeholder="""1) 오늘 감사 1가지:
(예: 가족과 함께한 저녁 식사에 감사합니다)

2) 오늘 말씀/적용(결단) 1가지:
(예: "두려워하지 말라" 이사야 41:10 - 내일 담대히 나아가겠습니다)

3) 오늘의 방해요인(분주함/유혹/감정 등):
(예: SNS에 시간을 많이 뺏겼다)""",
        height=200,
        label_visibility="collapsed"
    )
    
    # 태그 입력
    tags_input = st.text_input(
        "태그 (쉼표로 구분)",
        placeholder="예: 감사, 기도, 말씀, 예배, 공동체",
    )
    
    st.divider()
    
    # 제출 버튼
    submitted = st.form_submit_button("💾 저장하기", use_container_width=True, type="primary")
    
    if submitted:
        if not content.strip():
            st.warning("내용을 입력해주세요!")
        else:
            # 태그 파싱
            tags = [t.strip() for t in tags_input.split(",") if t.strip()]
            
            # 멀티모달 텍스트 합치기
            combined_content = content
            if st.session_state.transcribed_text:
                combined_content += f"\n\n[🎤 음성 전사]\n{st.session_state.transcribed_text}"
            if st.session_state.image_analysis:
                combined_content += f"\n\n[🖼️ 이미지 분석]\n{st.session_state.image_analysis}"
            
            # 결과 저장용 변수
            extractions = None
            clean_text = combined_content
            ai_reflection = None
            extraction_type = "rule_based"
            
            # === AI 기반 처리 (Step 3) ===
            if use_ai_extraction:
                with st.spinner("🤖 AI가 분석 중..."):
                    try:
                        from lib.openai_client import (
                            ingest_text, 
                            extract_structured_data,
                            generate_reflection as gen_reflection
                        )
                        
                        # Ingestor (선택적)
                        if use_ingestor:
                            ingested = ingest_text(combined_content)
                            if ingested:
                                clean_text = ingested
                        
                        # Extractor (Structured Outputs)
                        llm_extractions = extract_structured_data(clean_text)
                        if llm_extractions:
                            extractions = llm_extractions
                            extraction_type = "llm_extractor"
                        
                        # Reflector (선택적)
                        if generate_reflection:
                            ai_reflection = gen_reflection(clean_text)
                        
                    except ImportError as e:
                        st.warning(f"⚠️ OpenAI 모듈 로드 실패: {e}")
                    except Exception as e:
                        st.warning(f"⚠️ AI 처리 중 오류 (규칙 기반으로 대체): {e}")
            
            # === 규칙 기반 폴백 ===
            if extractions is None:
                extractions = extract_by_rules(combined_content)
                extraction_type = "rule_based"
            
            # === DB 저장 ===
            try:
                from lib.supabase_db import insert_checkin, insert_extraction, insert_artifact
                
                # 체크인 저장
                checkin_data = insert_checkin(
                    content=content,  # 원본 텍스트만 저장
                    mood=mood,
                    tags=tags,
                    metadata={
                        "energy": energy,
                        "clean_text": clean_text if clean_text != content else None,
                        "has_audio": bool(st.session_state.transcribed_text),
                        "has_image": bool(st.session_state.image_analysis)
                    },
                    user_id=user_id
                )
                
                if checkin_data:
                    checkin_id = checkin_data.get("id")
                    
                    # artifacts 저장 (멀티모달)
                    for artifact in st.session_state.uploaded_artifacts:
                        insert_artifact(
                            checkin_id=checkin_id,
                            artifact_type=artifact["type"],
                            storage_path=artifact["storage_path"],
                            metadata=artifact.get("metadata"),
                            original_name=artifact.get("original_name"),
                            file_size=artifact.get("file_size")
                        )
                    
                    # extraction 저장
                    if any(extractions.values()):
                        insert_extraction(
                            source_type="checkin",
                            source_id=checkin_id,
                            extraction_type=extraction_type,
                            data=extractions
                        )
                    
                    st.success("✅ 신앙 기록이 저장되었습니다!")
                    st.balloons()
                    
                    # === 자동 인덱싱 (토글 ON일 때만) ===
                    if st.session_state.get("auto_index_on_save", False):
                        from lib.config import get_openai_api_key
                        if not get_openai_api_key():
                            st.warning("⚠️ OpenAI API 키가 없어 자동 인덱싱을 건너뜁니다.")
                        else:
                            with st.spinner("🧠 자동 인덱싱 중..."):
                                try:
                                    from lib.rag import index_checkin, index_extraction
                                    
                                    # checkin 인덱싱: clean_text 우선(멀티모달/ingestor 반영)
                                    ok_checkin = index_checkin(checkin_id, clean_text, extractions)
                                    
                                    # extraction 인덱싱: 추출값이 비어있지 않을 때만
                                    ok_extraction = True
                                    try:
                                        if extractions and any(extractions.values()):
                                            ok_extraction = index_extraction(checkin_id, extraction_type, extractions)
                                    except Exception:
                                        ok_extraction = False
                                    
                                    if ok_checkin and ok_extraction:
                                        st.info("✅ 자동 인덱싱 완료 (Memory에서 즉시 검색 가능)")
                                    else:
                                        st.warning("⚠️ 자동 인덱싱 일부 실패 (체크인은 저장됨). 필요시 Memory에서 수동 동기화하세요.")
                                except Exception as e:
                                    st.warning(f"⚠️ 자동 인덱싱 오류 (체크인은 저장됨): {e}")
                    
                    # 세션 상태 초기화
                    st.session_state.transcribed_text = ""
                    st.session_state.image_analysis = ""
                    st.session_state.uploaded_artifacts = []
                    
                    # === 결과 표시 ===
                    with st.expander("📋 저장된 내용 확인", expanded=True):
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            st.markdown("**기본 정보**")
                            st.json({
                                "mood": mood,
                                "energy": energy,
                                "tags": tags,
                                "extraction_type": extraction_type,
                                "artifacts_count": len(st.session_state.uploaded_artifacts) if st.session_state.uploaded_artifacts else 0
                            })
                        
                        with col2:
                            st.markdown(f"**추출된 정보** (`{extraction_type}`)")
                            
                            if extractions.get("tasks"):
                                st.markdown("**📌 Tasks:**")
                                for task in extractions["tasks"]:
                                    st.markdown(f"  - {task}")
                            
                            if extractions.get("obstacles"):
                                st.markdown("**⚠️ Obstacles:**")
                                for obs in extractions["obstacles"]:
                                    st.markdown(f"  - {obs}")
                            
                            if extractions.get("projects"):
                                st.markdown(f"**📁 Projects:** {', '.join(extractions['projects'])}")
                            
                            if extractions.get("insights"):
                                st.markdown("**💡 Insights:**")
                                for ins in extractions["insights"]:
                                    st.markdown(f"  - {ins}")
                            
                            if extractions.get("people"):
                                st.markdown(f"**👥 People:** {', '.join(extractions['people'])}")
                            
                            if extractions.get("emotions"):
                                st.markdown(f"**😊 Emotions:** {', '.join(extractions['emotions'])}")
                            
                            if not any(extractions.values()):
                                st.caption("추출된 항목 없음")
                    
                    # AI 코멘트 표시
                    if ai_reflection:
                        st.divider()
                        st.subheader("💬 AI 코멘트")
                        st.info(ai_reflection)
                else:
                    st.error("저장 실패. 다시 시도해주세요.")
                    
            except ImportError as e:
                st.warning(f"⚠️ DB 모듈 로드 실패: {e}")
                # 데모 모드
                with st.expander("저장된 내용 (데모)", expanded=True):
                    st.json({
                        "mood": mood,
                        "energy": energy,
                        "content": content[:100] + "...",
                        "tags": tags,
                        "extractions": extractions,
                        "extraction_type": extraction_type
                    })
                if ai_reflection:
                    st.info(f"💬 AI: {ai_reflection}")
            except Exception as e:
                st.error(f"오류 발생: {e}")


# === 멀티모달 입력 섹션 ===
st.divider()
st.subheader("🎙️ 멀티모달 입력")

tab_audio, tab_image = st.tabs(["🎤 음성 입력", "🖼️ 이미지 입력"])

# --- 음성 입력 탭 ---
with tab_audio:
    st.markdown("**음성 파일을 업로드하면 텍스트로 변환됩니다**")
    
    audio_file = st.file_uploader(
        "음성 파일 선택",
        type=["mp3", "wav", "m4a", "ogg", "webm", "flac"],
        key="audio_uploader",
        help="지원 형식: MP3, WAV, M4A, OGG, WebM, FLAC"
    )
    
    st.info("💡 **권장 형식**: .mp3 (가장 안정적) | .m4a는 일부 호환성 문제가 있을 수 있습니다.")
    
    if audio_file is not None:
        # 오디오 미리보기
        st.audio(audio_file, format=f"audio/{audio_file.type.split('/')[-1] if audio_file.type else 'mpeg'}")
        
        if st.button("🎯 음성 → 텍스트 변환", key="transcribe_btn"):
            with st.spinner("🔄 음성을 텍스트로 변환 중..."):
                try:
                    from lib.openai_client import get_openai_client
                    from lib.supabase_storage import upload_file
                    
                    # 파일 정보 추출
                    file_name = audio_file.name
                    file_ext = file_name.split('.')[-1].lower() if '.' in file_name else 'mp3'
                    audio_bytes = audio_file.getvalue()
                    
                    # MIME type 매핑
                    mime_type_map = {
                        'mp3': 'audio/mpeg',
                        'm4a': 'audio/m4a',
                        'wav': 'audio/wav',
                        'ogg': 'audio/ogg',
                        'webm': 'audio/webm',
                        'flac': 'audio/flac'
                    }
                    content_type = audio_file.type or mime_type_map.get(file_ext, 'audio/mpeg')
                    
                    # 1. Supabase Storage에 업로드
                    storage_path = upload_file(
                        file_data=audio_bytes,
                        file_name=file_name,
                        content_type=content_type,
                        folder="audio-files"
                    )
                    
                    # 2. OpenAI Whisper로 전사 (tempfile 사용하여 실제 파일로 저장 후 전달)
                    client = get_openai_client()
                    transcribed = None
                    if not client:
                        st.error("OpenAI API 키가 설정되지 않았습니다.")
                    else:
                        # 임시 파일 생성 (확장자 포함)
                        with tempfile.NamedTemporaryFile(suffix=f'.{file_ext}', delete=False) as tmp_file:
                            tmp_file.write(audio_bytes)
                            tmp_path = tmp_file.name
                        
                        try:
                            # 임시 파일을 열어서 OpenAI API에 전달
                            with open(tmp_path, 'rb') as audio_file:
                                response = client.audio.transcriptions.create(
                                    model="whisper-1",
                                    file=audio_file,
                                    language="ko"
                                )
                                transcribed = response.text
                        finally:
                            # 임시 파일 삭제
                            if os.path.exists(tmp_path):
                                os.remove(tmp_path)
                    
                    if transcribed:
                        st.session_state.transcribed_text = transcribed
                        
                        # artifacts 정보 저장 (체크인 저장 시 DB에 기록)
                        st.session_state.uploaded_artifacts.append({
                            "type": "audio",
                            "storage_path": storage_path,
                            "original_name": audio_file.name,
                            "file_size": len(audio_bytes),
                            "metadata": {
                                "transcription": transcribed,
                                "duration": None
                            }
                        })
                        
                        st.success("✅ 음성 변환 완료!")
                    else:
                        st.error("음성 변환에 실패했습니다.")
                        
                except ImportError as e:
                    st.error(f"모듈 로드 실패: {e}")
                except Exception as e:
                    st.error(f"음성 변환 오류: {e}")
    
    # 전사된 텍스트 표시 및 편집
    if st.session_state.transcribed_text:
        st.markdown("---")
        st.markdown("**📝 변환된 텍스트** (편집 가능)")
        edited_transcription = st.text_area(
            "전사 결과",
            value=st.session_state.transcribed_text,
            height=100,
            key="edit_transcription",
            label_visibility="collapsed"
        )
        st.session_state.transcribed_text = edited_transcription
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button("📋 본문에 추가", key="add_transcription"):
                st.session_state.add_to_content = st.session_state.transcribed_text
                st.success("본문에 추가됨! 아래 내용란을 확인하세요.")
        with col2:
            if st.button("🗑️ 전사 내용 삭제", key="clear_transcription"):
                st.session_state.transcribed_text = ""
                st.rerun()


# --- 이미지 입력 탭 ---
with tab_image:
    st.markdown("**이미지를 업로드하면 AI가 내용을 분석합니다**")
    
    image_file = st.file_uploader(
        "이미지 파일 선택",
        type=["png", "jpg", "jpeg", "webp"],
        key="image_uploader",
        help="지원 형식: PNG, JPG, JPEG, WebP"
    )
    
    if image_file is not None:
        # 이미지 미리보기
        st.image(image_file, caption="업로드된 이미지", use_container_width=True)
        
        if st.button("🔍 이미지 분석", key="analyze_image_btn"):
            with st.spinner("🔄 이미지 분석 중..."):
                try:
                    from lib.openai_client import analyze_image
                    from lib.supabase_storage import upload_file
                    import base64
                    
                    # 1. Supabase Storage에 업로드
                    file_bytes = image_file.getvalue()
                    content_type = image_file.type or "image/jpeg"
                    
                    storage_path = upload_file(
                        file_data=file_bytes,
                        file_name=image_file.name,
                        content_type=content_type,
                        folder="image-files"
                    )
                    
                    # 2. Base64로 인코딩하여 Vision API 호출
                    base64_image = base64.b64encode(file_bytes).decode('utf-8')
                    image_url = f"data:{content_type};base64,{base64_image}"
                    
                    # 분석 프롬프트
                    analysis_prompt = """이 이미지에서 다음을 추출해주세요:
1. 이미지에 보이는 텍스트/메모 내용
2. 할 일 목록이 있다면 추출
3. 전체적인 맥락 요약 (한 문장)

간결하게 요점만 정리해주세요."""
                    
                    analysis_result = analyze_image(image_url, analysis_prompt)
                    
                    if analysis_result:
                        st.session_state.image_analysis = analysis_result
                        
                        # artifacts 정보 저장
                        st.session_state.uploaded_artifacts.append({
                            "type": "image",
                            "storage_path": storage_path,
                            "original_name": image_file.name,
                            "file_size": len(file_bytes),
                            "metadata": {
                                "analysis": analysis_result
                            }
                        })
                        
                        st.success("✅ 이미지 분석 완료!")
                    else:
                        st.error("이미지 분석에 실패했습니다.")
                        
                except ImportError as e:
                    st.error(f"모듈 로드 실패: {e}")
                except Exception as e:
                    st.error(f"오류 발생: {e}")
    
    # 분석 결과 표시 및 편집
    if st.session_state.image_analysis:
        st.markdown("---")
        st.markdown("**📝 분석 결과** (편집 가능)")
        edited_analysis = st.text_area(
            "분석 결과",
            value=st.session_state.image_analysis,
            height=100,
            key="edit_analysis",
            label_visibility="collapsed"
        )
        st.session_state.image_analysis = edited_analysis
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button("📋 본문에 추가", key="add_analysis"):
                st.session_state.add_to_content = st.session_state.image_analysis
                st.success("본문에 추가됨! 아래 내용란을 확인하세요.")
        with col2:
            if st.button("🗑️ 분석 내용 삭제", key="clear_analysis"):
                st.session_state.image_analysis = ""
                st.rerun()
